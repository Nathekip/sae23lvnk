<!DOCTYPE html>
<html>

<head>
    <?php
    include('fonctions.php');
    setup();
    ?>
    <meta charset="UTF-8">
</head>

<body>
    <?php
    echo '<div class="container-fluid">';
    pageheader();
    pagenavbar();
    echo '<h2>Pour réaliser les manipulations avec les differentes fonctions expliquées sur la page04, nous avons utilisé ce fichier "data.txt"</h2>';
    fichier_json();
    pagefooter();
    echo '<div>';
    ?>
</body>

</html>