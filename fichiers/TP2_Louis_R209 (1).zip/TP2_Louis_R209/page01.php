<!DOCTYPE html>
<html>
<head>
    <?php
        include('fonctions.php');
        setup();
    ?>
    <meta charset="UTF-8">
</head>
<body>
    <?php
        pageheader();
        pagenavbar(); 
        $j = file_get_contents('data/data.json');
        $livre = json_decode($j, true);
        echo showbooks($livre);
        pagefooter();
    ?>
</body>
</html>
