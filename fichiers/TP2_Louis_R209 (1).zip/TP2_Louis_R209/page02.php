<!DOCTYPE html>
<html>

<head>
    <?php
    include('fonctions.php');
    setup();
    ?>
    <meta charset="UTF-8">
</head>

<body>
    <div class="container-fluid text-center">

        <?php
        echo pageheader();
        echo pagenavbar();
        ?>
        <form action="page02.php" method="post">

            <label for="cars">Choix :</label>
            <br>
            <input type="checkbox" id="Auteur" name="author" value="true" onclick="showInput()">
            <label for="Auteur"> : Auteur</label><br>

            <input type="checkbox" id="Titre" name="title" value="true" onclick="showInput()">
            <label for="Titre"> : Titre</label><br>

            <div id="textInput" style="display:none">
                <label for="texte"> Recherche : </label>
                <input type="text" name="keyword" id="texte" style="padding-left: 10px;" required>
            </div>

            <input type="submit" value="Rechercher">
            <br><br>
        </form>

        <script>
            function showInput() {
                var textInput = document.getElementById("textInput");
                var searchAuteur = '';
                var searchTitre = '';

                if (document.getElementById("Auteur").checked) {
                    searchAuteur = "auteur";
                }

                if (document.getElementById("Titre").checked) {
                    searchTitre = "titre";
                }

                if (document.getElementById("Auteur").checked || document.getElementById("Titre").checked) {
                    textInput.style.display = "block";
                } else {
                    textInput.style.display = "none";
                }
            }
        </script>

        <?php
        $fields = array();
        if (isset($_POST['author'])){
            array_push($fields,'author');
        }
        if (isset($_POST['title'])){
            array_push($fields,'title');
        }
        if ($fields == []){
            $fields = ["id","title","content","author","date"];
        }
        $j = file_get_contents('data/data.json');    
        if (isset($_POST['keyword'])){
        $keyword = $_POST['keyword'];
        $livres = json_decode($j, true);
        findbooks($livres, $keyword, $fields);
        $j = file_get_contents('data/test.json');}
        $livres = json_decode($j, true);
        echo showbooks($livres);
        pagefooter();
        ?>
</body>

</html>