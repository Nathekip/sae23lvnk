<!DOCTYPE html>
<html>

<head>
    <?php
    include('fonctions.php');
    setup();
    ?>
    <meta charset="UTF-8">
    <title>Créer un utilisateur</title>
</head>

<body>
    <?php
    echo '<div class="container-fluid">';
    pageheader();
    pagenavbar();
    pagefooter();
    echo '</div>';
    ?>
    <h1>Créer un utilisateur</h1>
    <form method="post">
        <label for="usr">Nom d'utilisateur :</label>
        <input type="text" id="usr" name="usr" required>
        <br>
        <label for="mdp">Mot de passe :</label>
        <input type="mdp" id="mdp" name="mdp" required>
        <br>
        <label for="role">Rôle :</label>
        <select id="role" name="role" required>
            <option value="admin">Administrateur</option>
            <option value="user">Utilisateur</option>
            <option value="visitor">Visiteur</option>
        </select>
        <br>
        <input type="submit" value="Créer l'utilisateur">
    </form>

    <table>
        <thead>
            <tr>
            <th>Nom d'utilisateur</th>
            <th>Rôle</th>
            <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Charger le fichier JSON des utilisateurs
            $users_j = file_get_contents('users.json');
            $utilisateurs = json_decode($users_j, true);

            // Parcourir le tableau des utilisateurs et afficher chaque ligne du tableau HTML
            foreach ($utilisateurs as $user) {
            echo '<tr>';
            echo '<td>' . $user['user'] . '</td>';
            echo '<td>' . $user['role'] . '</td>';
            echo '<td><a href="delete_user.php?user=' . $user['user'] . '">Supprimer</a></td>';
            echo '</tr>';
            }
            ?>
        </tbody>
    </table>

    <?php
    // Charger le fichier JSON des utilisateurs
    $users_j = file_get_contents('users.json');
    $utilisateurs = json_decode($users_j, true);

    // Parcourir le tableau des utilisateurs et afficher chaque ligne du tableau HTML
    foreach ($utilisateurs as $user) {
      echo '<tr>';
      echo '<td>' . $user['user'] . '</td>';
      echo '<td>' . $user['role'] . '</td>';
      echo '<td><a href="delete_user.php?user=' . $user['user'] . '">Supprimer</a></td>';
      echo '</tr>';
    }
    ?>
  </tbody>
</table>


    <?php
    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Récupérer les données du formulaire
        $usr = $_POST['usr'];
        $mdp = $_POST['mdp'];
        $role = $_POST['role'];

        // Charger le fichier JSON des utilisateurs
        $users_j = file_get_contents('users.json');
        $utilisateurs = json_decode($users_j, true);

        // Enregistrer les modifications dans le fichier JSON
        $users_j = json_encode($utilisateurs, JSON_PRETTY_PRINT);
        file_put_contents('users.json', $users_j);

        // Rediriger vers la page d'accueil
        header('Location: page06.php');
        exit();
    }
    ?>
</body>

</html>