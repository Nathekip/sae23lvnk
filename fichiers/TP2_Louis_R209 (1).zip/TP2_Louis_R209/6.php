<!DOCTYPE html>
<html>
<head>
    <?php
        include('fonctions.php');
        setup();
    ?>
    <meta charset="UTF-8">
</head>
<body>
    <div class="container-fluid">
    <?php
        // Charger le contenu du fichier JSON dans une variable
        $users = file_get_contents('data/users.json');
        // Décoder le contenu JSON en un tableau associatif
        $utilisateurs = json_decode($users, true);
        ob_start();
        pageheader();
        pagenavbar();
        findUsers();
        deleteUser($utilisateurs);
        getUsers($utilisateurs);
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <?php addUsers(); ?>
        </form>

    </div>
    <foot>
        <div class="container-fluid">
            <?php
            pagefooter();
            ?>
        </div>
    </foot>
</body>
</html>
