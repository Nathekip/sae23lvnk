<!DOCTYPE html>
<html>

<head>
    <?php
    include('fonctions.php');
    setup();
    ?>
    <meta charset="UTF-8">
    <title>Explication du script</title>
</head>

<body>
    <?php
    echo '<div class="container-fluid text-center">';
    pageheader();
    pagenavbar();
    ?>
    <h1>Explication du script</h1>

    <p>Ce script permet de créer un formulaire de recherche avec deux options : la recherche par auteur et la recherche par titre.</p>

    <p>Le formulaire contient deux cases à cocher, une pour chaque option de recherche. Lorsqu'une case est cochée, une zone de texte apparaît pour permettre à l'utilisateur de saisir sa requête. Si les deux cases sont décochées, la zone de texte disparaît.</p>

            <label for="cars">Choix :</label>
            <br>
            <input type="checkbox" id="Auteur" name="Auteur" value="Auteur" onclick="showInput()">
            <label for="Auteur"> : Auteur</label><br>

            <input type="checkbox" id="Titre" name="Titre" value="Titre" onclick="showInput()">
            <label for="Titre"> : Titre</label><br>

            <div id="textInput" style="display:none">
                <label for="texte"> Recherche : </label>
                <input type="text" name="texte" id="texte" style="padding-left: 10px;" required>
            </div>

            <br><br>

            <input type="submit" value="Rechercher">
        </form>
    </div>

    <script>
        function showInput() {
            var textInput = document.getElementById("textInput");
            var searchAuteur = '';
            var searchTitre = '';

            if (document.getElementById("Auteur").checked) {
                searchAuteur = "auteur";
            }

            if (document.getElementById("Titre").checked) {
                searchTitre = "titre";
            }

            if (document.getElementById("Auteur").checked || document.getElementById("Titre").checked) {
                textInput.style.display = "block";
            } else {
                textInput.style.display = "none";
            }
        }
    </script>
    <br>
    <p>Ce script JavaScript permet d'afficher ou de masquer la zone de texte en fonction des choix de l'utilisateur. La fonction showInput() est appelée lorsqu'une case est cochée ou décochée. Elle vérifie les choix de l'utilisateur et affiche ou masque la zone de texte en conséquence.</p>
    <br><br>
</body>
<foot>
    <?php
    pagefooter();
    echo '</div>';
    ?>
</foot>

</html>