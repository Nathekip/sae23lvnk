sauvegarde fonctions
<?php
function setup()
{
    echo '<link rel="icon" href="image/icone.png">';
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">';
    $nomFichier = basename($_SERVER["SCRIPT_NAME"], ".php");
    switch ($nomFichier) {
        case "page01":
            echo '<title>Accueil</title>';
            break;
        case "page02":
            echo '<title>Formulaire</title>';
            break;
        case "page04":
            echo '<title>Informations</title>';
            break;
        case "page05":
            echo '<title>Fichiers</title>';
            break;
        case "page06":
            echo '<title>Administration</title>';
            break;
        default:
            echo '<title>?</title>';
            break;
    }
}
function pageheader()
{
    echo '<header>
            <div class="container-fluid bg-light text-center py-3">
                <h1>Biblio-check</h1>
                <div class="position-relative">
                    <div class="position-absolute top-0 end-0">
                        <button class="btn btn-primary" id="connexion" onclick="">Connexion</button>
                    </div>
                </div>
                <br><br>
            </div>
        </header>';
}
function pagenavbar()
{
    echo '<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <div class="container-fluid">
                <ul class="collapse navbar-collapse navbar-nav ml-auto" id="navbarNav">
                    <li class="nav-item active">
                        <a class="nav-link" href="page01.php">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page02.php">Formulaire</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page04.php">Informations</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page05.php">Fichiers</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page06.php">Administration</a>
                    </li>
                </ul>
            </div>
         </nav>';
}

function showbooks($livres)
{
    $tab = array();
    $rep = "";
    $rep .= <<<EOD
    
                <div class="container">
    <table class="table table-dark table-striped">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Titre</th>
            <th scope="col">Résumé</th>
            <th scope="col">Auteur</th>
            <th scope="col">Date</th>
            </tr>
        </thead>
        <tbody>
    EOD;

    $n = 0;
    foreach ($livres as $l) {
        #print_r($l);
        #echo "<br>";


        $tab[$n] = <<<EOD
            <tr>
            <th scope="row">identifiant</th>
            <td>title</td>
            <td>content</td>
            <td>author</td>
            <td>date</td>
            </tr>
        EOD;
        $tab[$n] = str_replace("identifiant", $l['id'], $tab[$n]);
        $tab[$n] = str_replace("title", $l['title'], $tab[$n]);
        $tab[$n] = str_replace("content", $l['content'], $tab[$n]);
        $tab[$n] = str_replace("author", $l['author'], $tab[$n]);
        $tab[$n] = str_replace("date", $l['date'], $tab[$n]);
        $rep .= $tab[$n];
        $n++;
    }

    $tabfin = <<<EOD
            </tbody>
    </table>
    </div>
    EOD;
    $rep .= $tabfin;
    return $rep;
}

function fichier_json()
{
    $json = file_get_contents("data/data.json");
    var_dump(json_decode($json));
}

function findBooks($livres, $keyword, $fields=[]) {
    $rep = array();

    if (empty($fields)) { // si la liste des champs est vide
        foreach ($livres as $l) {
            foreach ($l as $key => $value) {
                if (strpos($value, $keyword) !== false) {
                    array_push($rep, $l);
                    break; // on sort de la boucle dès qu'un livre correspond à la recherche
                }
            }
        }
    } else { // si la liste des champs n'est pas vide
        foreach ($livres as $l) {
            foreach ($fields as $field) {
                if (strpos($l[$field], $keyword) !== false) {
                    array_push($rep, $l);
                    break; // on sort de la boucle dès qu'un livre correspond à la recherche
                }
            }
        }
    }

    $fp = fopen("data/test.json", 'w');
    fwrite($fp, "");
    fclose($fp);

    $jsonString = json_encode($rep);
    $fp = fopen("data/test.json", 'a');
    fwrite($fp, $jsonString);
    fclose($fp);
}


function pagefooter()
{
    echo '<footer class=" text-dark">
            <div class="container-fluid text-center">
            <p class="mb-0">© 2023, Biblio-check</p>
            </div>
        </footer>';
}
function addUser($usr, $mdp, $role="user")
{
    // Charger le contenu du fichier JSON dans une variable
    $users = file_get_contents('data/users.json');

    // Décoder le contenu JSON en un tableau associatif
    $utilisateurs = json_decode($users, true);
    
    // Ajouter le nouvel utilisateur au tableau
    $utilisateurs[$usr] = array(
        'user' => $usr,
        'mdp' => password_hash($mdp, PASSWORD_DEFAULT),
        'role' => $role,
    );

    // Encoder le tableau en JSON et l'enregistrer dans le fichier
    $jsonStr = json_encode($utilisateurs, JSON_PRETTY_PRINT);
    file_put_contents('data/users.json', $jsonStr);
}
function add(){
    echo '<h2>Ajouter un utilisateur</h2>
    <div class="form-group">
        <label for="usr">Nom utilisateur :</label>
        <input type="text" class="form-control" id="usr" placeholder="Nom" name="usr" required>
    </div>
    <div class="form-group">
        <label for="mdp">Mot de passe :</label>
        <input type="password" class="form-control" id="mdp" placeholder="Mot de passe" name="mdp" required>
    </div>
    <div class="form-group">
        <label for="role">Rôle:</label>
        <select class="form-control" id="role" name="role">
            <option value="admin">Administrateur</option>
            <option value="user">Utilisateur</option>
            <option value="visitor">Visiteur</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Ajouter</button>';
}
function addUsers()
{
    add();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usr = $_POST['usr'];
    $mdp = $_POST['mdp'];
    $role = $_POST['role'];
    addUser($usr, $mdp, $role);
    // Recharger la page pour afficher la nouvelle liste des utilisateurs
    header('Location:' . $_SERVER['PHP_SELF']);
    ob_end_flush(); // Envoie le contenu de la mémoire tampon de sortie et arrête la mémoire tampon
    exit();
}
}
function getUsers($utilisateurs){
    echo '<h2>Utilisateurs correspondants</h2>';
    if(!is_array($utilisateurs)) {
        return;
    }

    echo '<table class="table container-fluid table-striped">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Nom</th>';
    echo '<th>Rôle</th>';
    echo '<th>Nouveau mot de passe</th>';
    echo '<th>Confirmation</th>';
    echo '<th>Validé</th>';
    echo '<th>Supprimer</th>';
    echo '</tr>';
    echo '</thead>';

    $search = isset($_GET['search']) ? strtolower(trim($_GET['search'])) : '';
    foreach ($utilisateurs as $user){
        if(empty($search) || strpos(strtolower($user['user']), $search) !== false) {
            echo '<tr>';
            echo '<td>' . $user['user'] . '</td>';
            echo '<td>';
            echo '<div class="form-group">';
            echo '<select class="form-control" id="role" name="role">';
            echo '<option value="admin" ' . ($user['role'] == 'admin' ? 'selected' : '') . '>Administrateur</option>';
            echo '<option value="user" ' . ($user['role'] == 'user' ? 'selected' : '') . '>Utilisateur</option>';
            echo '<option value="visitor" ' . ($user['role'] == 'visitor' ? 'selected' : '') . '>Visiteur</option>';
            echo '</select>';
            echo '</div>';
            echo '</td>';
            echo '<td><input type="password" class="form-control" name="new_mdp" placeholder="Nouveau mot de passe" required></td>';
            echo '<td><input type="password" class="form-control" name="confirmation" placeholder="Confirmation" required></td>';
            echo '<td><button class="btn btn-success" name="valider">Valider</button></td>';
            echo '<td><button class="btn btn-danger" name="supprimer">Supprimer</button></td>';
            echo '</tr>';
        }
    }
    echo '</table>';
}
function findUsers(){
    echo '<br><br>
    <h2>Rechercher un utilisateur</h2>
    <form class="form-inline my-2 my-lg-0" method="GET">
    <input class="form-control mr-sm-2" type="text" placeholder="Rechercher par nom" name="search">
    <button class="btn btn-primary" type="submit">Rechercher</button>
    </form>
    <br>';
}
function deleteUser($utilisateurs){
    if(isset($_POST['supprimer'])){
        $userToDelete = $_POST['userToDelete'];
        if(isset($utilisateurs[$userToDelete])){
            unset($utilisateurs[$userToDelete]);
            // Ré-afficher le tableau mis à jour
            getUsers($utilisateurs);
        }
    }
}

?>