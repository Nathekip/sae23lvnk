<!DOCTYPE html>
<html>
<head>
    <?php
    include('fonctions.php');
    setup();
    ?>
    <meta charset="UTF-8">
    <title>Administrer</title>
</head>
<body>
    <?php
        echo '<div class="container-fluid">';
        pageheader();
        pagenavbar();
        pagefooter();
        echo '</div>';
    ?>
    <h1>Administrer</h1>

    <form action="#" method="get">
        <label for="search_user">Rechercher un utilisateur :</label>
        <input type="text" id="search_user" name="search_user">
        <input type="submit" value="Rechercher">
    </form>

    <?php
    if (isset($_GET['search_user'])) {
        // Charger le fichier JSON des utilisateurs
        $users_j = file_get_contents('users.json');
        $utilisateurs = json_decode($users_j, true);

        // Récupérer la chaîne de recherche
        $search_string = $_GET['search_user'];

        // Filtrer les utilisateurs selon la chaîne de recherche
        $filtered_users = array_filter($utilisateurs, function ($user) use ($search_string) {
            return strpos($user['user'], $search_string) !== false;
        });

        // Afficher la liste des utilisateurs filtrés
        echo '<table>';
        echo '<thead><tr><th>Nom d\'utilisateur</th><th>Rôle</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        foreach ($filtered_users as $user) {
            echo '<tr>';
            echo '<td>' . $user['user'] . '</td>';
            echo '<td>' . $user['role'] . '</td>';
            echo '<td>';
            echo '<form method="post">';
            echo '<input type="hidden" name="edit_user" value="' . $user['user'] . '">';
            echo '<input type="submit" value="Modifier">';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';

        // Afficher un message si aucun utilisateur n'a été trouvé
        if (count($filtered_users) === 0) {
            echo '<p>Aucun utilisateur ne correspond à votre recherche.</p>';
        }
    } else {
                    // Charger le fichier JSON des utilisateurs
            $users_j = file_get_contents('users.json');
            $utilisateurs = json_decode($users_j, true);

            // Vérifier si le formulaire de modification a été soumis
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_user'])) {
                // Récupérer les données du formulaire
                $usr = $_POST['usr'];
                $mdp = $_POST['mdp'];
                $role = $_POST['role'];

                // Mettre à jour l'utilisateur dans le tableau
                $utilisateurs[$usr] = array(
                    'user' => $usr,
                    'mdp' => password_hash($mdp, PASSWORD_DEFAULT),
                    'role' => $role,
                );

                // Enregistrer les modifications dans le fichier JSON
                $users_j = json_encode($utilisateurs, JSON_PRETTY_PRINT);
                file_put_contents('users.json', $users_j);

                // Rediriger vers la page d'accueil
                header('Location: page06.php');
                exit();
            }

            // Vérifier si le formulaire de suppression a été soumis
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_user'])) {
                // Récupérer le nom d'utilisateur à supprimer
                $user_to_delete = $_POST['delete_user'];

                // Supprimer l'utilisateur du tableau
                unset($utilisateurs[$user_to_delete]);

                // Enregistrer les modifications dans le fichier JSON
                $users_j = json_encode($utilisateurs, JSON_PRETTY_PRINT);
                file_put_contents('users.json', $users_j);

                // Rediriger vers la page d'accueil
                header('Location: page06.php');
                exit();
            }

            echo '<div class="container-fluid">';
            pageheader();
            pagenavbar();
            echo '<h1>Administration des utilisateurs</h1>';

            // Barre de recherche pour filtrer les utilisateurs
            echo '<form method="post">';
            echo '<label for="search">Rechercher un utilisateur :</label>';
            echo '<input type="text" id="search" name="search">';
            echo '<input type="submit" value="Rechercher">';
            echo '</form>';

            echo '<table>';
            echo '<thead>';
            echo '<tr>';
            echo '<th>Nom d\'utilisateur</th>';
            echo '<th>Mot de passe</th>';
            echo '<th>Rôle</th>';
            echo '<th>Actions</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            // Parcourir le tableau des utilisateurs et afficher chaque ligne du tableau HTML
            foreach ($utilisateurs as $user) {
                // Filtrer les utilisateurs si une recherche a été effectuée
                if (isset($_POST['search']) && !empty($_POST['search'])) {
                    $search = $_POST['search'];
                    if (stripos($user['user'], $search) === false) {
                        continue;
                    }
                }

                echo '<tr>';
                echo '<form method="post">';
                echo '<td>' . $user['user'] . '</td>';
                echo '<td><input type="password" name="mdp" value=""></td>';
                echo '<td><input type="text" name="nom" value="' . $user['user'] . '"></td>';
                echo '<td><input type="email" name="email" value="' . $user['role'] . '"></td>';
                echo '<td><input type="submit" name="update" value="Modifier"></td>';
                echo '<td><input type="submit" name="delete" value="Supprimer"></td>';
                echo '</form>';
                echo '</tr>';
            }


             // Vérifier si le formulaire a été soumis pour modifier un utilisateur
    if (isset($_POST['update_user'])) {
        // Récupérer les données du formulaire
        $usr = $_POST['usr'];
        $mdp = $_POST['mdp'];
        $role = $_POST['role'];
        $old_user = $_POST['old_user'];

        // Charger le fichier JSON des utilisateurs
        $users_j = file_get_contents('users.json');
        $utilisateurs = json_decode($users_j, true);

        // Modifier l'utilisateur dans le tableau
        $utilisateurs[$usr] = array(
            'user' => $usr,
            'mdp' => password_hash($mdp, PASSWORD_DEFAULT),
            'role' => $role,
        );

        // Si le nom d'utilisateur a été modifié, supprimer l'ancien utilisateur
        if ($usr !== $old_user) {
            unset($utilisateurs[$old_user]);
        }

        // Enregistrer les modifications dans le fichier JSON
        $users_j = json_encode($utilisateurs, JSON_PRETTY_PRINT);
        file_put_contents('users.json', $users_j);

        // Rediriger vers la page d'accueil
        header('Location: page_admin.php');
        exit();
    }

    // Vérifier si le formulaire a été soumis pour supprimer un utilisateur
    if (isset($_POST['delete_user'])) {
        // Récupérer les données du formulaire
        $usr = $_POST['delete_user'];

        // Charger le fichier JSON des utilisateurs
        $users_j = file_get_contents('users.json');
        $utilisateurs = json_decode($users_j, true);

        // Supprimer l'utilisateur du tableau
        unset($utilisateurs[$usr]);

        // Enregistrer les modifications dans le fichier JSON
        $users_j = json_encode($utilisateurs, JSON_PRETTY_PRINT);
        file_put_contents('users.json', $users_j);

        // Rediriger vers la page d'accueil
        header('Location: page_admin.php');
        exit();
    }

?>
</body>
</html>